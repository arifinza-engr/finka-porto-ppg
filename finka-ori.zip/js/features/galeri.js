/* =========================================================
   PORTOFOLIO PPG — Galeri Foto (layout justify + filter + lightbox)
   Sumber data: Porto.data.galleryItems
   ========================================================= */
window.Porto = window.Porto || {};

Porto.gallery = (() => {
  const { $, $$, clamp, loadImage, preloadImage } = Porto.util;

  const MODAL_ID = "galleryModal";
  const SEM2_START = 27; // foto indeks 28 ke atas = semester 2
  const GAP = 14;
  const MIN_ROW_H = 120;
  const MAX_ROW_H = 340;

  const items = () => Porto.data.galleryItems ?? [];

  let galleryFilter = "all";
  let currentImageIndex = 0;
  let galleryReady = false;
  let revealObserver = null;
  let resizeTimer = null;
  let zoomed = false;

  /* ---------------------------------------------------------
     Utilitas
     --------------------------------------------------------- */
  const isSemester2 = (index) => index >= SEM2_START;

  const getVisibleItems = () => {
    const all = items().map((item, index) => ({ ...item, i: index }));
    if (galleryFilter === "1") return all.filter((item) => !isSemester2(item.i));
    if (galleryFilter === "2") return all.filter((item) => isSemester2(item.i));
    return all;
  };

  const columnsFor = (width) => {
    if (width >= 1180) return 5;
    if (width >= 900) return 4;
    if (width >= 640) return 3;
    if (width >= 320) return 2;
    return 1;
  };

  const srcOf = (item) => (item ? `assets/gallery/${item.f}` : null);

  /* ---------------------------------------------------------
     Render grid (layout justify ala Google Photos)
     --------------------------------------------------------- */
  const renderGallery = (animate = true) => {
    const grid = document.getElementById("galleryGrid");
    if (!grid) return;

    const width = grid.clientWidth;
    if (!width) return;

    const visibleItems = getVisibleItems();
    const cols = columnsFor(width);

    // Bagi item menjadi baris berisi `cols` foto
    const rows = [];
    for (let i = 0; i < visibleItems.length; i += cols) {
      rows.push(visibleItems.slice(i, i + cols));
    }

    grid.innerHTML = "";

    rows.forEach((row) => {
      const rowEl = document.createElement("div");
      rowEl.className = "g-row";

      const sumAr = row.reduce((acc, item) => acc + item.ar, 0);
      const gapTotal = GAP * (row.length - 1);
      const height = clamp(
        (width - gapTotal) / sumAr,
        MIN_ROW_H,
        MAX_ROW_H,
      );

      row.forEach((item) => {
        const el = document.createElement("figure");
        const itemWidth = Math.round(item.ar * height);
        const smt = isSemester2(item.i);

        el.className = "g-item";
        el.style.width = `${itemWidth}px`;
        el.style.height = `${Math.round(height)}px`;
        el.dataset.index = item.i;
        el.setAttribute("role", "button");
        el.setAttribute("tabindex", "0");
        el.setAttribute("aria-label", `Foto ${item.i + 1}`);

        el.innerHTML = `
        <img src="${srcOf(item)}" alt="Galeri ${item.i + 1}" loading="lazy" decoding="async" />
        <span class="g-badge" style="background:${smt ? "rgba(200,90,63,.75)" : "rgba(63,107,87,.75)"}">
          ${smt ? "SMT 2" : "SMT 1"}
        </span>
        <span class="g-zoom"><i class="fas fa-expand text-xs"></i></span>
        <span class="g-scrim"></span>
        <span class="g-caption">
          <span class="text-white text-sm font-bold leading-tight">Foto ${item.i + 1}</span>
          <span class="text-white/70 text-[11px] font-semibold">${smt ? "Semester 2" : "Semester 1"}</span>
        </span>
      `;

        el.addEventListener("click", () => open(item.i));
        el.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            open(item.i);
          }
        });

        rowEl.appendChild(el);
      });

      grid.appendChild(rowEl);
    });

    const counter = document.getElementById("galleryCount");
    if (counter) counter.textContent = visibleItems.length;

    setupReveal(grid);
    if (animate) animateGridIn();
  };

  /** Munculkan item saat masuk viewport */
  const setupReveal = (grid) => {
    revealObserver?.disconnect();
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-in");
          revealObserver.unobserve(entry.target);
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );

    grid.querySelectorAll(".g-item").forEach((el) => revealObserver.observe(el));
  };

  const animateGridIn = () => {
    const rows = $$("#galleryGrid .g-row");
    if (!rows.length || typeof gsap === "undefined") return;

    gsap.from(rows, {
      opacity: 0,
      y: 22,
      duration: 0.55,
      ease: "power2.out",
      stagger: 0.045,
      clearProps: "opacity,transform",
    });
  };

  /* ---------------------------------------------------------
     Filter
     --------------------------------------------------------- */
  const moveFilterIndicator = () => {
    const wrap = document.getElementById("galleryFilters");
    const indicator = document.getElementById("filterIndicator");
    if (!wrap || !indicator) return;

    const active = wrap.querySelector(".g-filter.is-active");
    if (!active) return;

    indicator.style.width = `${active.offsetWidth}px`;
    indicator.style.transform = `translateX(${active.offsetLeft}px)`;
  };

  const setGalleryFilter = (filter) => {
    if (galleryFilter === filter) return;
    galleryFilter = filter;

    $$("#galleryFilters .g-filter").forEach((btn) => {
      const isActive = btn.dataset.filter === filter;
      btn.classList.toggle("is-active", isActive);
      btn.setAttribute("aria-pressed", String(isActive));
    });
    moveFilterIndicator();

    const grid = document.getElementById("galleryGrid");
    const currentItems = grid.querySelectorAll(".g-item");

    if (typeof gsap === "undefined") {
      renderGallery(false);
      return;
    }

    // Keluar dengan animasi halus lalu bangun ulang layout
    // (ada jaring pengaman bila callback animasi tidak terpanggil).
    Porto.util.animateTo(
      currentItems,
      {
        opacity: 0,
        scale: 0.92,
        y: 12,
        duration: 0.28,
        ease: "power2.in",
        stagger: { amount: 0.18, from: "start" },
      },
      () => {
        renderGallery(false);
        animateGridIn();
      },
      500,
    );
  };

  /* ---------------------------------------------------------
     Lightbox
     --------------------------------------------------------- */
  const open = (index) => {
    const modal = document.getElementById(MODAL_ID);
    if (!modal) return;

    currentImageIndex = index;
    Porto.modal.open(MODAL_ID);

    const backdrop = document.getElementById("galleryBackdrop");
    if (backdrop && typeof gsap !== "undefined") {
      gsap.fromTo(
        backdrop,
        { opacity: 0 },
        { opacity: 1, duration: 0.4, ease: "power2.out" },
      );
      gsap.fromTo(
        $$(
          "#galleryModal .flex.items-start.justify-between > *, #galleryStage, #galleryCaption, #galleryFilmstrip",
        ),
        { opacity: 0, y: 14 },
        {
          opacity: 1,
          y: 0,
          duration: 0.5,
          ease: "power3.out",
          stagger: 0.05,
          delay: 0.08,
        },
      );
    }

    loadLightboxImage(index, 1);
    renderFilmstrip();
    updateNavButtons();
  };

  const loadLightboxImage = async (index, direction = 1) => {
    const img = document.getElementById("galleryImage");
    const loader = document.getElementById("galleryLoader");
    const item = items()[index];
    if (!img || !item) return;

    // Update info lebih dulu agar UI responsif (gambar menyusul)
    const counter = document.getElementById("galleryCounter");
    const total = document.getElementById("galleryTotal");
    const semester = document.getElementById("gallerySemester");
    const caption = document.getElementById("galleryCaption");
    const smt = isSemester2(index);

    if (counter) counter.textContent = index + 1;
    if (total) total.textContent = items().length;
    if (semester) {
      semester.textContent = smt ? "SMT 2" : "SMT 1";
      semester.className = `rounded-full px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.15em] text-white ${
        smt ? "bg-terracotta" : "bg-forest"
      }`;
    }
    if (caption) {
      caption.textContent = `Foto ${index + 1} dari ${items().length} — ${
        smt ? "Semester 2" : "Semester 1"
      }`;
    }

    loader?.classList.remove("hidden");
    loader?.classList.add("grid");

    await loadImage(img, srcOf(item));

    loader?.classList.add("hidden");
    loader?.classList.remove("grid");

    if (typeof gsap !== "undefined") {
      gsap.fromTo(
        img,
        { opacity: 0, scale: 0.94, x: direction * 26 },
        { opacity: 1, scale: 1, x: 0, duration: 0.55, ease: "power3.out" },
      );
    }

    // Preload gambar tetangga
    preloadImage(srcOf(items()[index + 1]));
    preloadImage(srcOf(items()[index - 1]));
  };

  const close = () => {
    const modal = document.getElementById(MODAL_ID);
    const backdrop = document.getElementById("galleryBackdrop");
    const img = document.getElementById("galleryImage");
    if (!modal) return;

    const finalize = () => {
      Porto.modal.close(MODAL_ID);
      if (img) {
        img.style.opacity = "";
        img.style.transform = "";
      }
    };

    if (typeof gsap === "undefined") {
      finalize();
      return;
    }

    gsap.to(img, {
      opacity: 0,
      scale: 0.94,
      duration: 0.25,
      ease: "power2.in",
    });

    // Jaring pengaman: lightbox tetap tertutup walau callback
    // animasi tidak pernah dipanggil browser.
    Porto.util.animateTo(
      backdrop,
      {
        opacity: 0,
        duration: 0.3,
        ease: "power2.in",
      },
      finalize,
      450,
    );
  };

  const next = () => {
    if (currentImageIndex < items().length - 1) {
      currentImageIndex += 1;
      loadLightboxImage(currentImageIndex, 1);
      updateNavButtons();
      syncFilmstrip();
    }
  };

  const prev = () => {
    if (currentImageIndex > 0) {
      currentImageIndex -= 1;
      loadLightboxImage(currentImageIndex, -1);
      updateNavButtons();
      syncFilmstrip();
    }
  };

  const updateNavButtons = () => {
    const prevBtn = document.getElementById("prevBtn");
    const nextBtn = document.getElementById("nextBtn");
    if (!prevBtn || !nextBtn) return;

    const atStart = currentImageIndex === 0;
    const atEnd = currentImageIndex === items().length - 1;

    const apply = () => {
      prevBtn.style.pointerEvents = atStart ? "none" : "auto";
      nextBtn.style.pointerEvents = atEnd ? "none" : "auto";
      prevBtn.style.opacity = atStart ? "0.3" : "1";
      nextBtn.style.opacity = atEnd ? "0.3" : "1";
    };

    if (typeof gsap === "undefined") {
      apply();
      return;
    }

    // Jaring pengaminanya: status tombol tetap ter-update walau callback
    // animasi tidak pernah dipanggil browser.
    Porto.util.animateTo(
      [prevBtn, nextBtn],
      {
        opacity: 1,
        duration: 0.3,
      },
      apply,
      400,
    );
  };

  /* ---------------------------------------------------------
     Filmstrip
     --------------------------------------------------------- */
  const renderFilmstrip = () => {
    const strip = document.getElementById("galleryFilmstrip");
    if (!strip) return;

    strip.innerHTML = items()
      .map(
        (item, index) => `
      <div class="g-thumb ${index === currentImageIndex ? "is-active" : ""}" data-index="${index}" title="Foto ${index + 1}" role="button" tabindex="0" aria-label="Foto ${index + 1}">
        <img src="${srcOf(item)}" alt="" loading="lazy" decoding="async" />
      </div>`,
      )
      .join("");

    strip.querySelectorAll(".g-thumb").forEach((thumb) => {
      const select = () => {
        currentImageIndex = Number(thumb.dataset.index);
        loadLightboxImage(currentImageIndex, 1);
        updateNavButtons();
        syncFilmstrip();
      };
      thumb.addEventListener("click", select);
      thumb.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          select();
        }
      });
    });

    syncFilmstrip();
  };

  const syncFilmstrip = () => {
    const strip = document.getElementById("galleryFilmstrip");
    if (!strip) return;

    strip.querySelectorAll(".g-thumb").forEach((thumb) => {
      thumb.classList.toggle(
        "is-active",
        Number(thumb.dataset.index) === currentImageIndex,
      );
    });

    const active = strip.querySelector(".g-thumb.is-active");
    active?.scrollIntoView?.({
      behavior: "smooth",
      block: "nearest",
      inline: "center",
    });
  };

  /* ---------------------------------------------------------
     Interaksi: zoom & swipe
     --------------------------------------------------------- */
  const bindImageInteraction = (img, stage) => {
    img.addEventListener("click", (event) => {
      event.stopPropagation();
      zoomed = !zoomed;

      if (zoomed) {
        const rect = img.getBoundingClientRect();
        const originX = ((event.clientX - rect.left) / rect.width) * 100;
        const originY = ((event.clientY - rect.top) / rect.height) * 100;

        if (typeof gsap !== "undefined") {
          gsap.to(img, {
            scale: 1.9,
            transformOrigin: `${originX}% ${originY}%`,
            duration: 0.5,
            ease: "power3.out",
          });
        }
        stage.style.overflow = "auto";
      } else {
        if (typeof gsap !== "undefined") {
          gsap.to(img, { scale: 1, duration: 0.4, ease: "power2.out" });
        }
        stage.style.overflow = "hidden";
      }
    });

    let touchX = null;
    let touchY = null;

    stage.addEventListener(
      "touchstart",
      (event) => {
        touchX = event.changedTouches[0].clientX;
        touchY = event.changedTouches[0].clientY;
      },
      { passive: true },
    );

    stage.addEventListener(
      "touchend",
      (event) => {
        if (touchX === null) return;
        const deltaX = event.changedTouches[0].clientX - touchX;
        const deltaY = event.changedTouches[0].clientY - touchY;

        if (Math.abs(deltaX) > 55 && Math.abs(deltaX) > Math.abs(deltaY)) {
          if (deltaX < 0) next();
          else prev();
        }
        touchX = null;
        touchY = null;
      },
      { passive: true },
    );
  };

  /* ---------------------------------------------------------
     Hero & scroll
     --------------------------------------------------------- */
  const animateGalleryHero = () => {
    const hero = document.getElementById("galleryHero");
    if (!hero) return;

    if (typeof gsap !== "undefined") {
      gsap.fromTo(
        hero,
        { opacity: 0, y: 26, scale: 0.985 },
        { opacity: 1, y: 0, scale: 1, duration: 0.7, ease: "power3.out" },
      );

      hero.querySelectorAll("[data-count]").forEach((el) => {
        const counter = { value: 0 };
        gsap.to(counter, {
          value: Number(el.dataset.count),
          duration: 1.2,
          ease: "power2.out",
          delay: 0.25,
          onUpdate: () => {
            el.textContent = Math.round(counter.value);
          },
        });
      });

      gsap.fromTo(
        hero.querySelectorAll(".g-stat"),
        { opacity: 0, y: 18 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: "power2.out",
          stagger: 0.08,
          delay: 0.15,
        },
      );
    }
  };

  /* ---------------------------------------------------------
     Parallax dekorasi hero (GSAP ScrollTrigger)
     --------------------------------------------------------- */
  const scrollTriggers = [];

  const initScroll = () => {
    killScroll();

    const hero = document.getElementById("galleryHero");
    if (!hero || typeof ScrollTrigger === "undefined") return;

    hero.querySelectorAll(".pointer-events-none").forEach((blob, index) => {
      scrollTriggers.push(
        ScrollTrigger.create({
          trigger: hero,
          start: "top top",
          end: "bottom top",
          scrub: 0.6,
          animation: gsap.to(blob, {
            y: index % 2 === 0 ? 70 : -50,
            ease: "none",
          }),
        }),
      );
    });

    ScrollTrigger.refresh();
  };

  const killScroll = () => {
    scrollTriggers.forEach((trigger) => trigger.kill());
    scrollTriggers.length = 0;
  };

  /* ---------------------------------------------------------
     Inisialisasi
     --------------------------------------------------------- */
  const init = () => {
    const grid = document.getElementById("galleryGrid");
    if (!grid) return;

    if (!galleryReady) {
      galleryReady = true;

      // Filter
      $$("#galleryFilters .g-filter").forEach((btn) => {
        btn.setAttribute("aria-pressed", String(btn.classList.contains("is-active")));
        btn.addEventListener("click", () => setGalleryFilter(btn.dataset.filter));
      });

      // Klik di luar modal -> tutup
      Porto.modal.bindBackdrop(MODAL_ID, close, {
        backdropId: "galleryBackdrop",
      });

      // Zoom gambar + swipe
      const img = document.getElementById("galleryImage");
      const stage = document.getElementById("galleryStage");
      if (img && stage) bindImageInteraction(img, stage);

      // Resize -> layout ulang
      window.addEventListener("resize", () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          if (document.getElementById("page-5")?.classList.contains("active")) {
            renderGallery(false);
          }
          moveFilterIndicator();
        }, 180);
      });

      // Navigasi keyboard
      document.addEventListener("keydown", (event) => {
        if (!Porto.modal.isOpen(MODAL_ID)) return;
        if (event.key === "ArrowLeft") prev();
        if (event.key === "ArrowRight") next();
      });
    }

    renderGallery(false);
    moveFilterIndicator();
    animateGalleryHero();
  };

  return {
    init,
    open,
    close,
    next,
    prev,
    renderGallery,
    initScroll,
    killScroll,
    $,
  };
})();
